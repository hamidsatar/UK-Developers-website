import { StatItem, Testimonial } from '../types';

export const COMPANY_INFO = {
  name: 'UK Developers',
  tagline: 'Developing More Than Expectations',
  shortAbout: 'UK Developers is a premier real estate development and construction enterprise headquartered in Lahore, Pakistan. Specializing in high-rise mixed-use towers, luxury residential suites, and grade-A commercial developments built to international engineering standards.',
  fullAbout: 'Founded with a vision to redefine urban architecture in Pakistan, UK Developers combines cutting-edge futuristic design, structural integrity, and transparent client partnerships. From landmark multi-story developments in DHA Karachi to luxury high-rises in Gulberg Lahore, every project stands as a testament to engineering precision, strict safety compliance, and unmatched aesthetic excellence.',
  phone: '+92 325 1114441',
  landline: '+92 42 3578 8888',
  whatsapp: '+923251114441',
  email: 'info@ukdevelopers.pk',
  salesEmail: 'sales@ukdevelopers.pk',
  locationAddress: 'CS-12 Block A Falcon Down Town, Lahore',
  officeHours: 'Monday – Saturday: 9:00 AM – 7:00 PM PST',
  socials: {
    facebook: 'https://facebook.com/ukdevelopers.pk',
    instagram: 'https://instagram.com/ukdevelopers.pk',
    linkedin: 'https://linkedin.com/company/ukdevelopers',
    youtube: 'https://youtube.com/ukdevelopers'
  }
};

export const COMPANY_STATS: StatItem[] = [
  {
    label: 'Years of Excellence',
    value: '15+',
    description: 'Delivering landmark structures across Pakistan',
    iconName: 'Award'
  },
  {
    label: 'Delivered Sq. Ft.',
    value: '2.5M+',
    description: 'High-quality residential and commercial real estate',
    iconName: 'Building2'
  },
  {
    label: 'On-Time Delivery',
    value: '100%',
    description: 'Adherence to engineering milestones and NOC approvals',
    iconName: 'CheckCircle2'
  },
  {
    label: 'Client Satisfaction',
    value: '99.2%',
    description: 'Trusted by overseas Pakistanis & institutional investors',
    iconName: 'Users'
  }
];

export const WHY_CHOOSE_US = [
  {
    title: 'Futuristic Architecture',
    description: 'Double-glazed glass facades, green energy integrations, and IoT smart home systems designed for tomorrow.',
    icon: 'Sparkles'
  },
  {
    title: '100% Legal & Approved',
    description: 'Full NOC approvals from LDA, DHA, and civil defense regulatory authorities with clear land titles.',
    icon: 'ShieldCheck'
  },
  {
    title: 'High ROI & Rental Yields',
    description: 'Prime urban locations ensuring capital appreciation and consistent double-digit rental returns.',
    icon: 'TrendingUp'
  },
  {
    title: 'NFPA Safety Standards',
    description: 'Equipped with pressurized fire stairs, automated sprinklers, and earthquake-resistant structural engineering.',
    icon: 'HardHat'
  },
  {
    title: 'Transparent Payment Plans',
    description: 'Flexible 3 to 4-year interest-free monthly and quarterly installment schedules with zero hidden charges.',
    icon: 'Coins'
  },
  {
    title: 'Overseas Investor Support',
    description: 'Dedicated client desk providing virtual walkthroughs, power of attorney assistance, and digital documentation.',
    icon: 'Globe'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Mian Tariq Mahmood',
    role: 'Overseas Investor (UK)',
    location: 'London, United Kingdom',
    projectPurchased: 'UK Center UK-01 (Grade-A Office)',
    comment: 'Investing with UK Developers from London was seamless. Their team provided weekly video construction logs, and the architectural quality of UK-01 in DHA surpassed all my expectations.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '2',
    name: 'Dr. Ayesha Al-Ghamdi',
    role: 'Resident & Surgeon',
    location: 'Lahore, Pakistan',
    projectPurchased: 'UK Heights Gulberg (2-Bed Suite)',
    comment: 'The location on Main Boulevard Gulberg combined with smart home automation made UK Heights the best choice for our family. Outstanding building safety and luxury finishings.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '3',
    name: 'Chaudhry Bilal Hassan',
    role: 'CEO, Nexus Logistics',
    location: 'Karachi, Pakistan',
    projectPurchased: 'UK Business Bay (Ground Outlets)',
    comment: 'As a commercial investor, rental yield and footfall are critical. UK Developers selected the perfect DHA Phase 6 hub. On-time delivery and top-notch elevator and power infrastructure!',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '4',
    name: 'Sultan Al-Otaibi',
    role: 'Real Estate Portfolio Manager',
    location: 'Riyadh, Saudi Arabia',
    projectPurchased: 'UK Vista Residences (Penthouse)',
    comment: 'UK Developers delivers world-class real estate in Pakistan. Their transparent payment plans and golf-view luxury developments compete with Dubai standards.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '5',
    name: 'Engr. Farhan Qureshi',
    role: 'Commercial Outlet Investor',
    location: 'Falcon Down Town, Lahore',
    projectPurchased: 'Commercial Unit - Block A',
    comment: 'Visiting their CS-12 Block A Falcon Down Town head office was a great experience. The team provided transparent legal documentation and an easy quarterly installment structure.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '6',
    name: 'Rabia & Kamran Abbasi',
    role: 'Homeowners',
    location: 'Islamabad, Pakistan',
    projectPurchased: 'UK Heights (3-Bed Luxury Suite)',
    comment: 'The acoustic insulation, high-speed elevators, and panoramic city view from our living room are outstanding. Living here truly feels like staying in a 5-star hotel.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '7',
    name: 'Sheikh Muhammad Zubair',
    role: 'Textile Exporter',
    location: 'Faisalabad, Pakistan',
    projectPurchased: 'UK Business Bay (Corporate Floor)',
    comment: 'UK Developers is one of the very few builders in Pakistan with 100% legal NOC clearances and an unblemished on-time construction record. Exceptional capital appreciation!',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    verified: true
  },
  {
    id: '8',
    name: 'Sarah Jenkins & Hamza Khan',
    role: 'Overseas Investors (UAE)',
    location: 'Dubai, UAE',
    projectPurchased: 'UK Center UK-01 (Luxury Apartment)',
    comment: 'The team at UK Developers handled our power of attorney and overseas transfer documentation without us having to travel. Double digit rental returns guaranteed.',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80',
    verified: true
  }
];
