import { Project } from '../types';

export const PROJECTS_DATA: Project[] = [
  {
    id: 'uk-01-center',
    title: 'UK Center UK-01',
    subtitle: 'DHA Mixed-Use Flagship Tower',
    location: 'Defence Housing Authority (DHA), Karachi / Phase 8 Executive District',
    city: 'Karachi / DHA',
    category: 'Mixed-Use',
    status: 'Now Booking',
    floors: 20,
    basementParkingLevels: 2,
    completionYear: 'Q4 2027',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'UK Center UK-01 is a landmark 20-story contemporary mixed-use tower engineered with international safety standards. Combining ultra-luxurious residential apartments, Grade-A smart corporate offices, and a bustling ground-level retail podium.',
    highlights: [
      '20 Floors including 2 dedicated underground parking levels',
      'Full NFPA Fire-Life-Safety compliant systems & pressurized smoke escape towers',
      'High-speed smart destination elevator system',
      '100% 24/7 Uninterrupted dual-generator backup power',
      'High-bandwidth fiber optic connectivity & IoT smart energy management'
    ],
    unitTypes: [
      {
        type: 'Ground & Mezzanine Retail Outlets',
        sizeRange: '350 - 1,800 Sq. Ft.',
        startingPricePKR: 'PKR 28.5 Million',
        downPayment: '20% (PKR 5.7M)',
        monthlyInstallment: 'PKR 350,000 / month'
      },
      {
        type: 'Grade-A Smart Corporate Offices',
        sizeRange: '550 - 2,400 Sq. Ft.',
        startingPricePKR: 'PKR 18.2 Million',
        downPayment: '15% (PKR 2.73M)',
        monthlyInstallment: 'PKR 215,000 / month'
      },
      {
        type: 'Luxury Executive 1 & 2 Bed Apartments',
        sizeRange: '720 - 1,450 Sq. Ft.',
        startingPricePKR: 'PKR 14.8 Million',
        downPayment: '15% (PKR 2.22M)',
        monthlyInstallment: 'PKR 175,000 / month'
      },
      {
        type: 'Exclusive Sky Penthouse Suites',
        sizeRange: '2,800 - 4,200 Sq. Ft.',
        startingPricePKR: 'PKR 48.0 Million',
        downPayment: '25% (PKR 12.0M)',
        monthlyInstallment: 'PKR 550,000 / month'
      }
    ],
    features: [
      'Double-height luxury glass lobby with concierge',
      'Automated Valet & RFID parking clearance',
      'Rooftop Infinity Swimming Pool & Executive Lounge',
      'Biometric access & 24/7 CCTV surveillance',
      'Earthquake resistant RCC structure (Zone 2B/3 compliant)',
      'Acoustic soundproof double-glazed curtain walls'
    ],
    paymentPlanOverview: 'Flexible 36-Month Easy Installment Plan with 15% Booking Amount and 10% Possession Payment.',
    paymentSchedule: [
      { stage: 'Booking / Down Payment', percentage: 15, amountPKR: '15% On Confirmation' },
      { stage: 'Allocation (30 days)', percentage: 10, amountPKR: '10% On Allocation' },
      { stage: '36 Monthly Installments', percentage: 50, amountPKR: '1.38% per month' },
      { stage: 'Half-Yearly Milestones (6 X)', percentage: 15, amountPKR: '2.5% every 6 months' },
      { stage: 'On Structural Possession', percentage: 10, amountPKR: '10% Upon Handover' }
    ]
  },
  {
    id: 'uk-heights-gulberg',
    title: 'UK Heights Gulberg',
    subtitle: 'Luxury Residential Suites & Corporate Hub',
    location: 'Main Boulevard Gulberg III, Near Liberty Roundabout, Lahore',
    city: 'Lahore',
    category: 'Residential',
    status: 'Now Booking',
    floors: 18,
    basementParkingLevels: 3,
    completionYear: 'Q2 2026',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'UK Heights Gulberg redefines elite vertical living in the heart of Lahore. Situated on Main Boulevard Gulberg, this 18-story architectural icon offers automated smart residences with panoramic views of the Lahore skyline.',
    highlights: [
      '18-Story iconic structure in Lahore commercial epicenter',
      'Smart Home IoT controls integrated in all apartments',
      'Dedicated executive floor with private meeting lounges',
      'LDA approved, clear NOC title'
    ],
    unitTypes: [
      {
        type: 'Studio Smart Suites',
        sizeRange: '450 - 580 Sq. Ft.',
        startingPricePKR: 'PKR 8.9 Million',
        downPayment: '15% (PKR 1.33M)',
        monthlyInstallment: 'PKR 95,000 / month'
      },
      {
        type: '1 Bed Luxury Apartments',
        sizeRange: '680 - 850 Sq. Ft.',
        startingPricePKR: 'PKR 12.5 Million',
        downPayment: '15% (PKR 1.87M)',
        monthlyInstallment: 'PKR 140,000 / month'
      },
      {
        type: '2 Bed Royal Residences',
        sizeRange: '1,200 - 1,550 Sq. Ft.',
        startingPricePKR: 'PKR 21.0 Million',
        downPayment: '15% (PKR 3.15M)',
        monthlyInstallment: 'PKR 240,000 / month'
      }
    ],
    features: [
      'Automated climate and lighting control via app',
      'Temperature-controlled indoor swimming pool',
      'Full gymnasium and wellness spa',
      'In-house cafe and cigar lounge',
      'Dedicated express lifts for residents'
    ],
    paymentPlanOverview: '3-Year Interest-Free Installment Plan. Booking starting from 15%.',
    paymentSchedule: [
      { stage: 'Booking', percentage: 15, amountPKR: '15% On Booking' },
      { stage: '36 Monthly Installments', percentage: 60, amountPKR: '1.66% per month' },
      { stage: 'Balloon Payments (Yearly x 3)', percentage: 15, amountPKR: '5% yearly' },
      { stage: 'Possession', percentage: 10, amountPKR: '10% On Handover' }
    ]
  },
  {
    id: 'uk-business-bay-dha6',
    title: 'UK Business Bay',
    subtitle: 'Next-Gen Commercial Outlets & Corporate Suites',
    location: 'Main Boulevard, DHA Phase 6, Ring Road Interchange, Lahore',
    city: 'Lahore',
    category: 'Commercial',
    status: 'Under Construction',
    floors: 14,
    basementParkingLevels: 2,
    completionYear: 'Q3 2026',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Designed as a high-footfall business boulevard in DHA Phase 6, UK Business Bay features double-height flagship retail showrooms, tech-enabled office floors, and executive dining decks.',
    highlights: [
      'Direct connectivity from Lahore Ring Road & Phase 6 Boulevard',
      'Double-height glass frontages for maximum retail visibility',
      'Solar energy integration lowering operational maintenance costs',
      'High rental yield projection (10% - 12% p.a.)'
    ],
    unitTypes: [
      {
        type: 'Flagship Ground Retail Outlets',
        sizeRange: '400 - 1,600 Sq. Ft.',
        startingPricePKR: 'PKR 24.0 Million',
        downPayment: '20% (PKR 4.8M)',
        monthlyInstallment: 'PKR 280,000 / month'
      },
      {
        type: 'Corporate Office Suites',
        sizeRange: '600 - 3,000 Sq. Ft.',
        startingPricePKR: 'PKR 15.5 Million',
        downPayment: '15% (PKR 2.32M)',
        monthlyInstallment: 'PKR 185,000 / month'
      }
    ],
    features: [
      'Central HVAC cooling system',
      'Conference hall & multimedia presentation center',
      'Multi-tiered security & access control',
      'Food court & alfresco dining balcony'
    ],
    paymentPlanOverview: '2.5 Years Quarterly Installment Plan with 20% Down Payment.',
    paymentSchedule: [
      { stage: 'Down Payment', percentage: 20, amountPKR: '20% On Booking' },
      { stage: '10 Quarterly Installments', percentage: 65, amountPKR: '6.5% every quarter' },
      { stage: 'Possession', percentage: 15, amountPKR: '15% On Handover' }
    ]
  },
  {
    id: 'uk-vista-residences',
    title: 'UK Vista Residences',
    subtitle: 'Golf-View Smart Luxury Apartments',
    location: 'DHA Raya Commercial / Phase 5, Lahore',
    city: 'Lahore',
    category: 'Residential',
    status: 'Now Booking',
    floors: 12,
    basementParkingLevels: 2,
    completionYear: 'Q1 2028',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Bespoke residential sanctuary overlooking green golf fairways in DHA Lahore. UK Vista Residences offers Italian fittings, private sky terraces, and smart climate technology.',
    highlights: [
      'Uninterrupted golf fairways & skyline park views',
      'Private terrace gardens with plunge pool options',
      'Integrated electric vehicle (EV) charging station',
      'Concealed VRF cooling & smart security'
    ],
    unitTypes: [
      {
        type: '1 Bed Golf Vista Apartment',
        sizeRange: '750 Sq. Ft.',
        startingPricePKR: 'PKR 16.5 Million',
        downPayment: '15% (PKR 2.47M)',
        monthlyInstallment: 'PKR 190,000 / month'
      },
      {
        type: '2 Bed Deluxe Sky Suite',
        sizeRange: '1,380 Sq. Ft.',
        startingPricePKR: 'PKR 27.0 Million',
        downPayment: '15% (PKR 4.05M)',
        monthlyInstallment: 'PKR 310,000 / month'
      },
      {
        type: '3 Bed Duplex Penthouse',
        sizeRange: '2,600 Sq. Ft.',
        startingPricePKR: 'PKR 49.5 Million',
        downPayment: '20% (PKR 9.9M)',
        monthlyInstallment: 'PKR 580,000 / month'
      }
    ],
    features: [
      'Private keycard elevator access directly to floor',
      'Heated pool, jacuzzi & sauna facilities',
      'Resident valet service & electric buggy transfers',
      'State-of-the-art security with AI motion analytics'
    ],
    paymentPlanOverview: '4-Year Quarterly Payment Plan tailored for investors and overseas Pakistanis.',
    paymentSchedule: [
      { stage: 'Booking', percentage: 15, amountPKR: '15% On Confirmation' },
      { stage: '16 Quarterly Payments', percentage: 70, amountPKR: '4.375% per quarter' },
      { stage: 'Handover & Keys', percentage: 15, amountPKR: '15% On Possession' }
    ]
  },
  {
    id: 'uk-executive-tower',
    title: 'UK Executive Tower',
    subtitle: 'Modern Commercial & Living Complex',
    location: 'Lake City Main Boulevard / Raiwind Road, Lahore',
    city: 'Lahore',
    category: 'Mixed-Use',
    status: 'Nearly Complete',
    floors: 10,
    basementParkingLevels: 1,
    completionYear: 'Q1 2026',
    image: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1582407947304-fd86f028f716?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'A sleek 10-story mixed tower offering high-return commercial spaces and modern studio/1-bed apartments on Raiwind Road, adjacent to major education and healthcare hubs.',
    highlights: [
      '90% Civil structure completed',
      'Prime location near Ring Road Raiwind Interchange',
      'Ideal for rental income generation from university faculty and executives'
    ],
    unitTypes: [
      {
        type: 'Commercial Shops',
        sizeRange: '280 - 850 Sq. Ft.',
        startingPricePKR: 'PKR 11.2 Million',
        downPayment: '20% (PKR 2.24M)',
        monthlyInstallment: 'PKR 150,000 / month'
      },
      {
        type: 'Executive Apartments',
        sizeRange: '520 - 920 Sq. Ft.',
        startingPricePKR: 'PKR 7.8 Million',
        downPayment: '15% (PKR 1.17M)',
        monthlyInstallment: 'PKR 90,000 / month'
      }
    ],
    features: [
      'Ready for interior finishing',
      'Dedicated commercial & residential entry gates',
      'High speed lifts & backup generators',
      'Covered car parking'
    ],
    paymentPlanOverview: 'Short-term 1.5-year easy plan with immediate possession options.',
    paymentSchedule: [
      { stage: 'Booking', percentage: 20, amountPKR: '20% On Booking' },
      { stage: '18 Monthly Installments', percentage: 60, amountPKR: '3.33% monthly' },
      { stage: 'On Key Handover', percentage: 20, amountPKR: '20% On Handover' }
    ]
  }
];
