import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { PaymentCalculator } from './components/PaymentCalculator';
import { WhyChooseUs } from './components/WhyChooseUs';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { BookingModal } from './components/BookingModal';
import { Project } from './types';

export default function App() {
  const [selectedProjectForModal, setSelectedProjectForModal] = useState<Project | null>(null);
  const [bookingModalOpen, setBookingModalOpen] = useState<boolean>(false);
  const [bookingProjectName, setBookingProjectName] = useState<string | undefined>(undefined);
  const [bookingUnitType, setBookingUnitType] = useState<string | undefined>(undefined);

  const handleOpenBooking = (projectName?: string, unitType?: string) => {
    setBookingProjectName(projectName);
    setBookingUnitType(unitType);
    setBookingModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#080c15] text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Glass Navbar */}
      <Navbar onOpenBooking={handleOpenBooking} />

      {/* Main Page Sections */}
      <main>
        {/* Section 1: Hero */}
        <Hero onOpenBooking={handleOpenBooking} />

        {/* Section 2: About Us */}
        <AboutSection onOpenBooking={() => handleOpenBooking()} />

        {/* Section 3: Current Projects & Deals */}
        <ProjectsSection
          onSelectProject={(proj) => setSelectedProjectForModal(proj)}
          onQuickBook={(projectName) => handleOpenBooking(projectName)}
        />

        {/* Section 4: Interactive Payment Plan Calculator */}
        <PaymentCalculator onOpenBooking={(projectName) => handleOpenBooking(projectName)} />

        {/* Section 5: Why Choose Us */}
        <WhyChooseUs onOpenBooking={() => handleOpenBooking()} />

        {/* Section 6: Client Testimonials */}
        <TestimonialsSection />

        {/* Section 7: Contact Us */}
        <ContactSection preselectedProject={bookingProjectName} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Project Detail Modal */}
      <ProjectDetailModal
        project={selectedProjectForModal}
        onClose={() => setSelectedProjectForModal(null)}
        onBookProject={(projName, unitType) => {
          setSelectedProjectForModal(null);
          handleOpenBooking(projName, unitType);
        }}
      />

      {/* Direct Booking & Consultation Modal */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        preselectedProjectName={bookingProjectName}
        preselectedUnitType={bookingUnitType}
      />
    </div>
  );
}
