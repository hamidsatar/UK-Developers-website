export interface PaymentPlanItem {
  stage: string;
  percentage: number;
  amountPKR: string;
  notes?: string;
}

export interface UnitTypeInfo {
  type: string; // e.g., '1 Bed Apartment', 'Grade-A Office', 'Retail Shop'
  sizeRange: string; // e.g., '650 - 1,200 Sq. Ft.'
  startingPricePKR: string;
  downPayment: string;
  monthlyInstallment: string;
}

export interface Project {
  id: string;
  title: string;
  subtitle: string;
  location: string;
  city: string;
  category: 'Mixed-Use' | 'Residential' | 'Commercial';
  status: 'Now Booking' | 'Under Construction' | 'Nearly Complete' | 'Delivered';
  floors: number;
  basementParkingLevels: number;
  completionYear: string;
  image: string;
  gallery: string[];
  description: string;
  highlights: string[];
  unitTypes: UnitTypeInfo[];
  features: string[];
  paymentPlanOverview: string;
  paymentSchedule: PaymentPlanItem[];
  coords?: { lat: number; lng: number };
  brochureUrl?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  projectPurchased: string;
  comment: string;
  rating: number;
  avatar: string;
  verified: boolean;
}

export interface StatItem {
  label: string;
  value: string;
  description: string;
  iconName: string;
}

export interface ContactFormData {
  fullName: string;
  phone: string;
  email: string;
  projectOfInterest: string;
  unitType: string;
  budgetRange: string;
  message: string;
}
