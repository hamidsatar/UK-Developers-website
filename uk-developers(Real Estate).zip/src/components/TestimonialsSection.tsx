import React, { useState } from 'react';
import { TESTIMONIALS } from '../data/companyData';
import { Star, ChevronLeft, ChevronRight, Quote, CheckCircle2, MessageSquare, ThumbsUp } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1));
  };

  const currentTestimonial = TESTIMONIALS[currentIndex];

  return (
    <section id="testimonials" className="relative py-24 bg-[#080c15] text-white">
      {/* Background Accent */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
            <span>Verified Client Feedback ({TESTIMONIALS.length} Reviews)</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            What Our <span className="text-gradient-cyan">Investors Say</span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
            Read authentic reviews from homeowners, commercial buyers, and overseas Pakistanis who chose UK Developers for their real estate investments.
          </p>
        </div>

        {/* Testimonial Spotlight Featured Carousel Card */}
        <div className="max-w-4xl mx-auto">
          <div className="relative p-8 sm:p-12 rounded-3xl glass-panel border border-white/10 space-y-8 shadow-2xl overflow-hidden">
            <Quote className="absolute top-6 right-8 w-20 h-20 text-white/5 pointer-events-none" />

            {/* Stars & Verified Badge */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(currentTestimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                ))}
              </div>

              {currentTestimonial.verified && (
                <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Verified Buyer
                </span>
              )}
            </div>

            {/* Comment Text */}
            <blockquote className="text-base sm:text-xl text-slate-200 italic leading-relaxed font-light">
              "{currentTestimonial.comment}"
            </blockquote>

            {/* Author Profile */}
            <div className="flex items-center justify-between pt-6 border-t border-white/10">
              <div className="flex items-center gap-4">
                <img
                  src={currentTestimonial.avatar}
                  alt={currentTestimonial.name}
                  className="w-14 h-14 rounded-full object-cover border-2 border-cyan-400/50 shadow-md"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-heading font-bold text-white text-lg">
                    {currentTestimonial.name}
                  </h4>
                  <p className="text-xs text-cyan-300 font-medium">
                    {currentTestimonial.role} — {currentTestimonial.location}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Purchased: <strong className="text-slate-300">{currentTestimonial.projectPurchased}</strong>
                  </p>
                </div>
              </div>

              {/* Navigation Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  className="p-3 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-white/10"
                  id="testimonial_prev_btn"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-3 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-white/10"
                  id="testimonial_next_btn"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Indicators */}
          <div className="flex justify-center gap-2 mt-6">
            {TESTIMONIALS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  currentIndex === idx ? 'w-8 bg-cyan-400' : 'bg-slate-700 hover:bg-slate-500'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>

        {/* All Reviews Grid */}
        <div className="space-y-6 pt-8 border-t border-white/10">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-xl font-bold text-white flex items-center gap-2">
              <ThumbsUp className="w-5 h-5 text-cyan-400" />
              <span>All Verified Client Reviews</span>
            </h3>
            <span className="text-xs text-slate-400">
              Showing 8 of 8 Client Experiences
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TESTIMONIALS.map((t, idx) => (
              <div
                key={t.id}
                onClick={() => setCurrentIndex(idx)}
                className={`p-5 rounded-2xl glass-panel border transition-all cursor-pointer flex flex-col justify-between space-y-4 hover:border-cyan-500/50 ${
                  currentIndex === idx
                    ? 'border-cyan-400 bg-cyan-950/30 shadow-lg shadow-cyan-500/10'
                    : 'border-white/10'
                }`}
                id={`review_card_${t.id}`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(t.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    {t.verified && (
                      <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Verified
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300 italic line-clamp-4 leading-relaxed">
                    "{t.comment}"
                  </p>
                </div>

                <div className="flex items-center gap-3 pt-3 border-t border-white/10">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    className="w-9 h-9 rounded-full object-cover shrink-0 border border-cyan-400/40"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <p className="font-bold text-white text-xs truncate">{t.name}</p>
                    <p className="text-[10px] text-cyan-300 truncate">{t.role}</p>
                    <p className="text-[9px] text-slate-400 truncate">{t.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
