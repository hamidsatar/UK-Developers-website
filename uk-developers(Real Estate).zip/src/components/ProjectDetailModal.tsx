import React, { useState } from 'react';
import { Project } from '../types';
import { X, Building2, MapPin, Layers, CheckCircle2, ShieldCheck, Sparkles, Phone, ArrowRight, Download, Calendar } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface ProjectDetailModalProps {
  project: Project | null;
  onClose: () => void;
  onBookProject: (projectName: string, unitType?: string) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onBookProject,
}) => {
  if (!project) return null;

  const [activeImage, setActiveImage] = useState<string>(project.image);
  const [activeTab, setActiveTab] = useState<'overview' | 'units' | 'payment' | 'features'>('overview');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-950/80 backdrop-blur-xl animate-fadeIn">
      {/* Modal Container */}
      <div className="relative w-full max-w-5xl my-8 rounded-3xl glass-panel border border-white/15 shadow-2xl overflow-hidden bg-[#0b0f19] text-white">
        
        {/* Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between p-6 bg-[#080c15]/90 backdrop-blur-md border-b border-white/10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {project.category}
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {project.status}
              </span>
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-white mt-1">
              {project.title}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-full bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
            id="modal_close_btn"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-8 max-h-[80vh] overflow-y-auto custom-scrollbar">
          
          {/* Main Visual Gallery & Quick Specs */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Gallery Column */}
            <div className="lg:col-span-7 space-y-3">
              <div className="relative h-72 sm:h-96 rounded-2xl overflow-hidden border border-white/10 shadow-lg">
                <img
                  src={activeImage}
                  alt={project.title}
                  className="w-full h-full object-cover object-center transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white bg-slate-950/80 backdrop-blur-md p-3 rounded-xl border border-white/10">
                  <span className="flex items-center gap-1 text-cyan-300 font-semibold">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    {project.location}
                  </span>
                  <span className="text-[11px] text-slate-400">Completion: {project.completionYear}</span>
                </div>
              </div>

              {/* Gallery Thumbnails */}
              {project.gallery && project.gallery.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  {project.gallery.map((imgUrl, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImage(imgUrl)}
                      className={`relative w-20 h-16 rounded-xl overflow-hidden border shrink-0 transition-all ${
                        activeImage === imgUrl
                          ? 'border-cyan-400 ring-2 ring-cyan-500/50 scale-105'
                          : 'border-white/10 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={imgUrl} alt={`Thumbnail ${idx}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Specs Column */}
            <div className="lg:col-span-5 space-y-6">
              <div className="space-y-2">
                <p className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">{project.subtitle}</p>
                <p className="text-xs text-slate-300 leading-relaxed">{project.description}</p>
              </div>

              {/* Key Specs Card Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">Total Floors</p>
                  <p className="text-sm font-bold text-white flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-cyan-400" />
                    {project.floors} Floors
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">Underground Parking</p>
                  <p className="text-sm font-bold text-white">
                    {project.basementParkingLevels} Basement Levels
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">Est. Handover</p>
                  <p className="text-sm font-bold text-amber-300">{project.completionYear}</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-white/5 space-y-1">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider">Approval NOC</p>
                  <p className="text-sm font-bold text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4" />
                    100% Verified
                  </p>
                </div>
              </div>

              {/* Quick Booking CTA */}
              <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-300 font-medium">Have questions or want to visit the site?</span>
                </div>
                <button
                  onClick={() => onBookProject(project.title)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2"
                  id={`modal_book_now_cta_${project.id}`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Request Official Payment Plan & Booking</span>
                </button>
              </div>
            </div>

          </div>

          {/* Navigation Tabs inside Modal */}
          <div className="border-b border-white/10 flex items-center gap-4 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('overview')}
              className={`pb-3 transition-colors border-b-2 ${
                activeTab === 'overview' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Key Highlights
            </button>
            <button
              onClick={() => setActiveTab('units')}
              className={`pb-3 transition-colors border-b-2 ${
                activeTab === 'units' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Available Unit Types
            </button>
            <button
              onClick={() => setActiveTab('payment')}
              className={`pb-3 transition-colors border-b-2 ${
                activeTab === 'payment' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Payment Plan Schedule
            </button>
            <button
              onClick={() => setActiveTab('features')}
              className={`pb-3 transition-colors border-b-2 ${
                activeTab === 'features' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Safety & Amenities
            </button>
          </div>

          {/* Tab 1: Highlights */}
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <h4 className="font-heading text-lg font-bold text-white">Project Highlights & Engineering Scope</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {project.highlights.map((highlight, i) => (
                  <div key={i} className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-900/60 border border-white/5">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                    <span className="text-xs text-slate-200">{highlight}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 2: Available Units */}
          {activeTab === 'units' && (
            <div className="space-y-4">
              <h4 className="font-heading text-lg font-bold text-white">Unit Inventory & Pricing</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {project.unitTypes.map((unit, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-900/80 border border-white/10 space-y-3 hover:border-cyan-500/40 transition-all">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-cyan-300">{unit.type}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">{unit.sizeRange}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                      <div>
                        <p className="text-[10px] text-slate-400 uppercase">Starting Price</p>
                        <p className="font-bold text-emerald-400">{unit.startingPricePKR}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 uppercase">Down Payment</p>
                        <p className="font-semibold text-white">{unit.downPayment}</p>
                      </div>
                    </div>

                    <p className="text-[11px] text-cyan-400 pt-1 border-t border-white/5">
                      Installment: <span className="text-white font-medium">{unit.monthlyInstallment}</span>
                    </p>

                    <button
                      onClick={() => onBookProject(project.title, unit.type)}
                      className="w-full py-2 rounded-lg bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 text-xs font-semibold transition-all"
                    >
                      Book This Unit
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Payment Plan */}
          {activeTab === 'payment' && (
            <div className="space-y-4">
              <div>
                <h4 className="font-heading text-lg font-bold text-white">Payment Schedule</h4>
                <p className="text-xs text-slate-400">{project.paymentPlanOverview}</p>
              </div>

              <div className="overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="p-3">Stage / Milestone</th>
                      <th className="p-3">Percentage (%)</th>
                      <th className="p-3">Schedule / Amount Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {project.paymentSchedule.map((item, idx) => (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="p-3 font-semibold text-white">{item.stage}</td>
                        <td className="p-3 text-cyan-300 font-bold">{item.percentage}%</td>
                        <td className="p-3 text-slate-300">{item.amountPKR}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 4: Features */}
          {activeTab === 'features' && (
            <div className="space-y-4">
              <h4 className="font-heading text-lg font-bold text-white">Architectural Features & Building Amenities</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {project.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900/60 border border-white/5 text-xs text-slate-200">
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-6 bg-[#080c15] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <Phone className="w-4 h-4 text-cyan-400" />
            <span>Call Sales Desk: <strong className="text-white">{COMPANY_INFO.phone}</strong></span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
            >
              Close
            </button>

            <button
              onClick={() => onBookProject(project.title)}
              className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-all flex items-center gap-1.5 shadow-lg shadow-cyan-500/20"
            >
              <span>Reserve Unit Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
