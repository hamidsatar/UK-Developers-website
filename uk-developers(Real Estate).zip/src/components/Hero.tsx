import React from 'react';
import { ArrowRight, Building, ShieldCheck, Sparkles, MapPin, Award, ChevronDown } from 'lucide-react';
import { COMPANY_INFO } from '../data/companyData';

interface HeroProps {
  onOpenBooking: (projectName?: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section id="hero" className="relative min-h-screen pt-28 pb-16 flex items-center justify-center overflow-hidden bg-[#080c15]">
      {/* Background Architectural Image with Dark Gradient Mask */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=2000&q=85"
          alt="UK Developers Lahore Skyline"
          className="w-full h-full object-cover object-center scale-105 filter brightness-50 contrast-125 transition-transform duration-1000"
          referrerPolicy="no-referrer"
        />
        {/* Dark futuristic gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#080c15] via-[#080c15]/75 to-[#080c15]/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#080c15] via-transparent to-[#080c15]/80" />
        <div className="absolute inset-0 bg-grid-pattern opacity-30" />
      </div>

      {/* Futuristic Glowing Ambient Orbs */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-cyan-500/15 rounded-full blur-[120px] pointer-events-none animate-pulse-glow" />
      <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-blue-600/15 rounded-full blur-[140px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Copy */}
          <div className="lg:col-span-7 text-left space-y-6">
            {/* Status Badge */}
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full glass-panel border border-cyan-500/30 text-cyan-300 text-xs sm:text-sm font-medium shadow-lg shadow-cyan-500/10">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-white font-semibold">PREMIER REAL ESTATE DEVELOPER</span>
              <span className="text-slate-400">|</span>
              <span className="text-cyan-300">LAHORE & KARACHI</span>
            </div>

            {/* Headline */}
            <h1 className="font-heading text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1]">
              Developing <br />
              <span className="text-gradient-cyan">More Than</span> <br />
              <span className="text-gradient-gold">Expectations.</span>
            </h1>

            {/* Subheadline */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl font-light leading-relaxed">
              Pioneering futuristic architectural landmarks, high-rise luxury towers, and Grade-A commercial complexes across Pakistan with engineered precision and 100% safety compliance.
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <a
                href="#projects"
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 text-white font-semibold text-sm sm:text-base shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-98 transition-all"
                id="hero_explore_projects_btn"
              >
                <span>Explore Current Deals</span>
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>

              <button
                onClick={() => onOpenBooking()}
                className="inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl glass-panel text-slate-200 hover:text-white hover:border-cyan-500/40 font-semibold text-sm sm:text-base transition-all"
                id="hero_book_consultation_btn"
              >
                <Sparkles className="w-5 h-5 text-amber-400" />
                <span>Book a Consultation</span>
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 border-t border-white/10 flex flex-wrap items-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>LDA & DHA Approved Titles</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-cyan-400" />
                <span>15+ Years Construction Record</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-amber-400" />
                <span>Lahore & Karachi Prime Zones</span>
              </div>
            </div>
          </div>

          {/* Futuristic Highlight Card (UK-01 Spotlight) */}
          <div className="lg:col-span-5">
            <div className="relative group">
              {/* Card Glow border */}
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-blue-500 to-amber-500 rounded-3xl blur-lg opacity-40 group-hover:opacity-75 transition duration-500" />
              
              <div className="relative glass-panel rounded-2xl p-6 sm:p-8 space-y-6 border border-white/15">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    FLAGSHIP PROJECT
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-cyan-400" />
                    20 Floors Tower
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="font-heading text-2xl sm:text-3xl font-bold text-white">
                    UK Center UK-01
                  </h3>
                  <p className="text-xs text-cyan-300 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    DHA Phase 8 Executive District, Karachi
                  </p>
                </div>

                <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed">
                  Mixed-use tower with premium apartments, Grade-A smart corporate offices, 2 underground parking levels, full NFPA fire safety, and backup power.
                </p>

                {/* Micro Stats */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Starting Price</p>
                    <p className="text-sm sm:text-base font-bold text-emerald-400">PKR 14.8M</p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Installments</p>
                    <p className="text-sm sm:text-base font-bold text-cyan-300">36 Months Easy</p>
                  </div>
                </div>

                <button
                  onClick={() => onOpenBooking('UK Center UK-01')}
                  className="w-full py-3 rounded-xl bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/40 text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-2"
                  id="hero_uk01_reserve_btn"
                >
                  <span>Inquire Units in UK-01</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Down Arrow indicator */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 p-2 rounded-full glass-panel text-slate-400 hover:text-white transition-colors animate-bounce"
        aria-label="Scroll down"
      >
        <ChevronDown className="w-5 h-5 text-cyan-400" />
      </a>
    </section>
  );
};
