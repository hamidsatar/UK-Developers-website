import React from 'react';
import { COMPANY_INFO, COMPANY_STATS } from '../data/companyData';
import { Building2, ShieldCheck, Award, Users, CheckCircle2, ArrowUpRight, Sparkles } from 'lucide-react';

interface AboutSectionProps {
  onOpenBooking: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenBooking }) => {
  return (
    <section id="about" className="relative py-24 bg-[#080c15] text-white overflow-hidden">
      {/* Background Accent Grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15 pointer-events-none" />
      <div className="absolute -top-32 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-cyan-400 text-xs font-semibold tracking-wider uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Trusted Engineering & Construction</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            About <span className="text-gradient-cyan">UK Developers</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Headquartered in Lahore, Pakistan, UK Developers stands at the forefront of futuristic architectural engineering, luxury urban residences, and high-yield commercial developments.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Visual Showcase / Image Collage */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden glass-panel p-2 border border-white/10 shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
                alt="UK Developers Construction Project"
                className="w-full h-80 sm:h-[420px] object-cover rounded-xl filter contrast-110 brightness-90 hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080c15] via-transparent to-transparent rounded-xl opacity-80" />
              
              {/* Overlay Badge */}
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl glass-panel border border-cyan-500/30 backdrop-blur-xl flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold text-cyan-300 uppercase tracking-widest">HQ Operations</p>
                  <p className="text-sm font-bold text-white">Gulberg III & DHA Phase 5, Lahore</p>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-semibold border border-cyan-500/30">
                  EST. 2011
                </div>
              </div>
            </div>

            {/* Floating Metric Pill */}
            <div className="absolute -top-6 -right-4 hidden sm:flex items-center gap-3 p-4 rounded-2xl glass-panel border border-amber-500/30 shadow-2xl glow-gold animate-float">
              <div className="p-3 rounded-xl bg-amber-500/20 text-amber-300">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <p className="text-lg font-bold text-white">2.5M+ Sq. Ft.</p>
                <p className="text-[11px] text-slate-400">Delivered Infrastructure</p>
              </div>
            </div>
          </div>

          {/* Text Description & Pillars */}
          <div className="lg:col-span-6 space-y-6">
            <h3 className="font-heading text-2xl sm:text-3xl font-bold text-white leading-snug">
              Constructing Tomorrow’s Landmarks With Uncompromising Integrity.
            </h3>

            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              {COMPANY_INFO.fullAbout}
            </p>

            {/* Core Commitments List */}
            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/50 border border-white/5">
                <CheckCircle2 className="w-5 h-5 text-cyan-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-white">Structural Safety & Earthquake Resistance</h4>
                  <p className="text-xs text-slate-400">Engineered according to seismic zone parameters with high-grade RCC and RCC raft foundations.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/50 border border-white/5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-white">100% On-Time Completion Track Record</h4>
                  <p className="text-xs text-slate-400">Rigorous milestone tracking ensuring transparent handover dates for investors and homeowners.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/50 border border-white/5">
                <CheckCircle2 className="w-5 h-5 text-amber-400 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-white">End-to-End Overseas Client Services</h4>
                  <p className="text-xs text-slate-400">Seamless online documentation, virtual site visits, and dedicated account managers for non-resident Pakistanis.</p>
                </div>
              </div>
            </div>

            <div className="pt-4 flex items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="px-6 py-3 rounded-xl bg-cyan-500 text-slate-950 font-semibold text-sm hover:bg-cyan-400 transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/20"
                id="about_consultation_btn"
              >
                <span>Schedule Executive Meeting</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>

        {/* Stats Grid Banner */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6">
          {COMPANY_STATS.map((stat, idx) => (
            <div
              key={idx}
              className="glass-panel rounded-2xl p-6 text-center space-y-2 border border-white/10 hover:border-cyan-500/40 transition-all duration-300"
            >
              <p className="font-heading text-3xl sm:text-4xl font-extrabold text-gradient-cyan">
                {stat.value}
              </p>
              <p className="text-xs font-semibold text-white uppercase tracking-wider">
                {stat.label}
              </p>
              <p className="text-[11px] text-slate-400 leading-tight">
                {stat.description}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
