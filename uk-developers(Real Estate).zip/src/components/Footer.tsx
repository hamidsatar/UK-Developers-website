import React from 'react';
import { COMPANY_INFO } from '../data/companyData';
import { Building2, ArrowUp, Phone, Mail, MapPin, ShieldCheck, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#050810] text-slate-400 border-t border-white/10 pt-16 pb-12 overflow-hidden">
      {/* Background Accent Grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <a href="#hero" className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 p-[1px]">
                <div className="w-full h-full bg-[#080c15] rounded-[11px] flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-cyan-400" />
                </div>
              </div>
              <div>
                <span className="font-heading font-extrabold text-xl tracking-wider text-white">
                  UK <span className="text-cyan-400">DEVELOPERS</span>
                </span>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest">
                  Developing More Than Expectations
                </p>
              </div>
            </a>

            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              {COMPANY_INFO.shortAbout}
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-300 pt-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>LDA & DHA Approved Developments</span>
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="lg:col-span-3 space-y-3 text-xs">
            <h4 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Navigation & Projects
            </h4>
            <ul className="space-y-2">
              <li><a href="#hero" className="hover:text-cyan-400 transition-colors">Home Banner</a></li>
              <li><a href="#about" className="hover:text-cyan-400 transition-colors">About Company</a></li>
              <li><a href="#projects" className="hover:text-cyan-400 transition-colors">UK Center UK-01 (DHA Karachi)</a></li>
              <li><a href="#projects" className="hover:text-cyan-400 transition-colors">UK Heights Gulberg (Lahore)</a></li>
              <li><a href="#projects" className="hover:text-cyan-400 transition-colors">UK Business Bay (DHA Phase 6)</a></li>
              <li><a href="#calculator" className="hover:text-cyan-400 transition-colors">Payment Calculator</a></li>
              <li><a href="#contact" className="hover:text-cyan-400 transition-colors">Schedule Consultation</a></li>
            </ul>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-4 space-y-3 text-xs">
            <h4 className="font-heading text-sm font-bold text-white uppercase tracking-wider">
              Lahore Headquarters
            </h4>
            <ul className="space-y-2 text-slate-300">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{COMPANY_INFO.locationAddress}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{COMPANY_INFO.phone}</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{COMPANY_INFO.email}</span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar & Copyright */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} UK Developers (Pvt) Ltd. All Rights Reserved.</p>

          <p className="flex items-center gap-1">
            <span>Crafted with engineering perfection in Lahore, Pakistan</span>
          </p>

          <button
            onClick={scrollToTop}
            className="p-2.5 rounded-xl bg-slate-900 border border-white/10 text-slate-400 hover:text-white hover:border-cyan-500/40 transition-all flex items-center gap-1.5 text-[11px]"
            id="footer_scroll_top_btn"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>

      </div>
    </footer>
  );
};
