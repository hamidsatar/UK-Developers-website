import React, { useState } from 'react';
import { Project } from '../types';
import { Building2, MapPin, Layers, ArrowRight, Shield, Sparkles, CheckCircle } from 'lucide-react';

interface ProjectCardProps {
  project: Project;
  onSelectProject: (project: Project) => void;
  onQuickBook: (projectName: string) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onSelectProject,
  onQuickBook,
}) => {
  const [transformStyle, setTransformStyle] = useState({});

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const rotateX = ((y - centerY) / centerY) * -8; // -8deg max tilt
    const rotateY = ((x - centerX) / centerX) * 8; // 8deg max tilt

    setTransformStyle({
      transform: `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`,
      transition: 'transform 0.1s ease-out',
    });
  };

  const handleMouseLeave = () => {
    setTransformStyle({
      transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)',
      transition: 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
    });
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={transformStyle}
      className="group relative rounded-2xl glass-panel-interactive border border-white/10 overflow-hidden flex flex-col justify-between h-full cursor-pointer shadow-xl"
      id={`project_card_${project.id}`}
    >
      {/* Glow highlight effect */}
      <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500/0 via-cyan-500/20 to-blue-500/0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

      {/* Image Thumbnail Header */}
      <div>
        <div className="relative h-64 overflow-hidden rounded-t-2xl">
          <img
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 filter brightness-95 group-hover:brightness-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f19] via-[#0b0f19]/30 to-transparent" />

          {/* Status Badge */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-cyan-500/80 backdrop-blur-md text-white border border-cyan-300/40 shadow-lg">
              {project.status}
            </span>
            <span className="px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-900/80 backdrop-blur-md text-slate-200 border border-white/10">
              {project.category}
            </span>
          </div>

          {/* Floors Count Badge */}
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white bg-slate-950/70 backdrop-blur-md px-3.5 py-2 rounded-xl border border-white/10">
            <div className="flex items-center gap-1.5 font-semibold text-cyan-300">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>{project.floors} Floors</span>
              {project.basementParkingLevels > 0 && (
                <span className="text-slate-400 font-normal">
                  (+{project.basementParkingLevels} Basement Parking)
                </span>
              )}
            </div>
            <span className="text-[11px] font-medium text-slate-300">{project.city}</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          <div>
            <h3 className="font-heading text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">
              {project.title}
            </h3>
            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="truncate">{project.location}</span>
            </p>
          </div>

          <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
            {project.description}
          </p>

          {/* Unit Types Tags */}
          <div className="space-y-1.5 pt-1">
            <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Available Units:</p>
            <div className="flex flex-wrap gap-1.5">
              {project.unitTypes.slice(0, 3).map((unit, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 rounded-lg bg-slate-900/80 text-[11px] text-slate-200 border border-white/5 font-medium"
                >
                  {unit.type}
                </span>
              ))}
              {project.unitTypes.length > 3 && (
                <span className="px-2 py-1 rounded-lg bg-cyan-500/10 text-[10px] text-cyan-300">
                  +{project.unitTypes.length - 3} More
                </span>
              )}
            </div>
          </div>

          {/* Price & Installment bar */}
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/5 flex items-center justify-between text-xs">
            <div>
              <p className="text-[10px] text-slate-400 uppercase">Starting From</p>
              <p className="text-sm font-bold text-emerald-400">{project.unitTypes[0]?.startingPricePKR || 'On Request'}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-slate-400 uppercase">Down Payment</p>
              <p className="text-xs font-semibold text-cyan-300">{project.unitTypes[0]?.downPayment || 'Flexible'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Card Footer Actions */}
      <div className="p-6 pt-0 grid grid-cols-2 gap-2 mt-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSelectProject(project);
          }}
          className="w-full py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-white/10 transition-all flex items-center justify-center gap-1.5"
          id={`btn_view_details_${project.id}`}
        >
          <span>View Details</span>
          <ArrowRight className="w-3.5 h-3.5 text-cyan-400" />
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onQuickBook(project.title);
          }}
          className="w-full py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold border border-cyan-500/40 transition-all flex items-center justify-center gap-1 shadow-sm"
          id={`btn_book_now_${project.id}`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>Inquire Deal</span>
        </button>
      </div>
    </div>
  );
};
