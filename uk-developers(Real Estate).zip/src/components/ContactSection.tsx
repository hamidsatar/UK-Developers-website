import React, { useState } from 'react';
import { COMPANY_INFO } from '../data/companyData';
import { PROJECTS_DATA } from '../data/projectsData';
import { ContactFormData } from '../types';
import { Phone, Mail, MapPin, MessageSquare, Send, CheckCircle2, Clock, Sparkles } from 'lucide-react';

interface ContactSectionProps {
  preselectedProject?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ preselectedProject }) => {
  const [formData, setFormData] = useState<ContactFormData>({
    fullName: '',
    phone: '',
    email: '',
    projectOfInterest: preselectedProject || 'UK Center UK-01 (DHA Karachi)',
    unitType: 'Residential Apartment',
    budgetRange: 'PKR 1.5 Crore - 3.0 Crore',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1000);
  };

  return (
    <section id="contact" className="relative py-24 bg-[#080c15] text-white">
      {/* Background Orbs */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-cyan-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>24/7 Investor Desk</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            Connect With <span className="text-gradient-cyan">UK Developers</span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
            Schedule a site visit, request official floor plans, or consult with our investment advisors in Lahore and Karachi.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Contact Information & Action Cards */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Quick Action Buttons Bar */}
            <div className="p-6 rounded-2xl glass-panel border border-cyan-500/30 space-y-4 shadow-xl">
              <h3 className="font-heading text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <span>Instant Inquiry Channels</span>
              </h3>

              <div className="grid grid-cols-1 gap-3">
                {/* WhatsApp Button */}
                <a
                  href={`https://wa.me/${COMPANY_INFO.whatsapp}?text=Hello%20UK%20Developers,%20I%20would%20like%20to%20inquire%20about%20your%20projects.`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-4 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 font-semibold text-xs sm:text-sm transition-all"
                  id="contact_whatsapp_direct_btn"
                >
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-5 h-5 text-emerald-400" />
                    <div>
                      <p className="text-white font-bold">Chat on WhatsApp</p>
                      <p className="text-[11px] text-emerald-300/80">Instant responses 24/7</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-[10px]">Open Chat</span>
                </a>

                {/* Direct Phone Call */}
                <a
                  href={`tel:${COMPANY_INFO.phone}`}
                  className="flex items-center justify-between p-4 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 font-semibold text-xs sm:text-sm transition-all"
                  id="contact_phone_direct_btn"
                >
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-cyan-400" />
                    <div>
                      <p className="text-white font-bold">Call UAN Helpline</p>
                      <p className="text-[11px] text-cyan-300/80">{COMPANY_INFO.phone}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-cyan-500/20 text-[10px]">Call Now</span>
                </a>
              </div>
            </div>

            {/* Address & Office Details */}
            <div className="p-6 rounded-2xl glass-panel border border-white/10 space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white text-sm">Headquarters & Sales Office</p>
                  <p className="text-slate-300 mt-0.5">{COMPANY_INFO.locationAddress}</p>
                  <p className="text-[11px] text-slate-500 mt-1">Lahore, Pakistan</p>
                </div>
              </div>

              <div className="flex items-start gap-3 border-t border-white/10 pt-3">
                <Mail className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white text-sm">Email Inquiries</p>
                  <p className="text-cyan-300 mt-0.5">{COMPANY_INFO.email}</p>
                  <p className="text-slate-400 text-[11px]">{COMPANY_INFO.salesEmail}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 border-t border-white/10 pt-3">
                <Clock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-white text-sm">Working Hours</p>
                  <p className="text-slate-300 mt-0.5">{COMPANY_INFO.officeHours}</p>
                </div>
              </div>
            </div>

            {/* Embedded Google Map */}
            <div className="rounded-2xl overflow-hidden border border-white/10 h-52 relative">
              <iframe
                title="UK Developers Lahore Map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13612.353347903264!2d74.3486121!3d31.51261!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190483e58107d9%3A0xc23abe6ccc7e2462!2sGulberg%20III%2C%20Lahore%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1700000000000!5m2!1sen!2s"
                className="w-full h-full border-0 filter grayscale invert contrast-125 brightness-75"
                allowFullScreen
                loading="lazy"
              />
            </div>

          </div>

          {/* Contact Inquiry Form */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl glass-panel border border-white/10 space-y-6 shadow-2xl">
            <div className="space-y-1">
              <h3 className="font-heading text-2xl font-bold text-white">
                Book a Private Consultation / Site Visit
              </h3>
              <p className="text-xs text-slate-400">
                Fill in your details to receive official brochures, price lists, and floor plan layouts directly on WhatsApp & Email.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-4 animate-fadeIn">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center border border-emerald-500/40">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="font-heading text-xl font-bold text-white">Inquiry Received Successfully!</h4>
                <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                  Thank you, <strong className="text-white">{formData.fullName}</strong>. A senior real estate consultant from UK Developers Lahore will reach out to you via WhatsApp at <strong className="text-cyan-300">{formData.phone}</strong> shortly.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({
                      fullName: '',
                      phone: '',
                      email: '',
                      projectOfInterest: 'UK Center UK-01 (DHA Karachi)',
                      unitType: 'Residential Apartment',
                      budgetRange: 'PKR 1.5 Crore - 3.0 Crore',
                      message: '',
                    });
                  }}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Full Name */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="e.g. Mian Shahzaib"
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                      id="contact_form_name"
                    />
                  </div>

                  {/* Phone / WhatsApp */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Phone / WhatsApp Number *</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+92 300 0000000"
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                      id="contact_form_phone"
                    />
                  </div>

                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Email */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="name@example.com"
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                      id="contact_form_email"
                    />
                  </div>

                  {/* Project of Interest */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Project of Interest</label>
                    <select
                      value={formData.projectOfInterest}
                      onChange={(e) => setFormData({ ...formData, projectOfInterest: e.target.value })}
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                      id="contact_form_project_select"
                    >
                      {PROJECTS_DATA.map((p) => (
                        <option key={p.id} value={p.title}>
                          {p.title} ({p.city})
                        </option>
                      ))}
                      <option value="General Consultation">General Real Estate Advisory</option>
                    </select>
                  </div>

                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Unit Type */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Unit Type</label>
                    <select
                      value={formData.unitType}
                      onChange={(e) => setFormData({ ...formData, unitType: e.target.value })}
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                      id="contact_form_unittype"
                    >
                      <option value="Residential Apartment">Residential Apartment / Penthouse</option>
                      <option value="Grade-A Corporate Office">Grade-A Corporate Office</option>
                      <option value="Ground / Podium Retail Shop">Ground / Podium Retail Shop</option>
                    </select>
                  </div>

                  {/* Budget */}
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-300 font-semibold">Estimated Budget Range</label>
                    <select
                      value={formData.budgetRange}
                      onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                      className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                      id="contact_form_budget"
                    >
                      <option value="PKR 80 Lakhs - 1.5 Crore">PKR 80 Lakhs – 1.5 Crore</option>
                      <option value="PKR 1.5 Crore - 3.0 Crore">PKR 1.5 Crore – 3.0 Crore</option>
                      <option value="PKR 3.0 Crore - 5.0 Crore+">PKR 3.0 Crore – 5.0 Crore+</option>
                    </select>
                  </div>

                </div>

                {/* Message */}
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-300 font-semibold">Additional Requirements / Notes</label>
                  <textarea
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about your preferred payment plan, floor preference, or site visit date..."
                    className="w-full p-3 rounded-xl bg-slate-900 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                    id="contact_form_message"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 text-white font-extrabold text-sm hover:shadow-lg hover:shadow-cyan-500/25 transition-all flex items-center justify-center gap-2"
                  id="contact_form_submit_btn"
                >
                  {loading ? (
                    <span>Transmitting Inquiry...</span>
                  ) : (
                    <>
                      <span>Submit Inquiry to Sales Desk</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
