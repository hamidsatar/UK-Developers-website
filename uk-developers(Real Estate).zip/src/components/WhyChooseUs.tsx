import React from 'react';
import { WHY_CHOOSE_US } from '../data/companyData';
import { Sparkles, ShieldCheck, TrendingUp, HardHat, Coins, Globe, Award, CheckCircle } from 'lucide-react';

interface WhyChooseUsProps {
  onOpenBooking: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenBooking }) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-cyan-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-emerald-400" />;
      case 'TrendingUp':
        return <TrendingUp className="w-6 h-6 text-amber-400" />;
      case 'HardHat':
        return <HardHat className="w-6 h-6 text-cyan-400" />;
      case 'Coins':
        return <Coins className="w-6 h-6 text-emerald-400" />;
      case 'Globe':
        return <Globe className="w-6 h-6 text-indigo-400" />;
      default:
        return <Award className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="why-us" className="relative py-24 bg-[#080c15] text-white overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Unmatched Value Proposition</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            Why Invest With <span className="text-gradient-cyan">UK Developers?</span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
            Built on a solid foundation of legal transparency, engineering precision, and client-centric installment structures across Pakistan’s fastest-growing urban corridors.
          </p>
        </div>

        {/* Grid of 6 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {WHY_CHOOSE_US.map((item, idx) => (
            <div
              key={idx}
              className="glass-panel-interactive rounded-2xl p-8 space-y-4 border border-white/10 hover:border-cyan-500/40 transition-all duration-300 relative group"
            >
              <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-white/10 w-fit group-hover:scale-110 transition-transform">
                {getIcon(item.icon)}
              </div>

              <h3 className="font-heading text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                {item.title}
              </h3>

              <p className="text-xs text-slate-300 leading-relaxed">
                {item.description}
              </p>

              <div className="pt-2 flex items-center gap-1 text-[11px] font-semibold text-cyan-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Verified Standards</span>
              </div>
            </div>
          ))}
        </div>

        {/* Overseas Pakistanis Highlight Bar */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-r from-blue-950/60 via-slate-900/90 to-cyan-950/60 border border-cyan-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 uppercase">
                Dedicated Service Desk
              </span>
              <span className="text-xs text-amber-300 font-semibold">UK / Gulf / USA Non-Residents</span>
            </div>
            <h3 className="font-heading text-xl sm:text-2xl font-bold text-white">
              Are you an Overseas Pakistani looking for high rental yields?
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              We offer virtual walkthroughs, online bank transfers via Roshan Digital Account (RDA), and power of attorney verification for zero hassle.
            </p>
          </div>

          <button
            onClick={onOpenBooking}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs sm:text-sm hover:shadow-cyan-500/30 shadow-lg shrink-0"
            id="why_us_overseas_btn"
          >
            Connect With Overseas Desk
          </button>
        </div>

      </div>
    </section>
  );
};
