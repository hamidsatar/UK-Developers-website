import React, { useState } from 'react';
import { PROJECTS_DATA } from '../data/projectsData';
import { Calculator, Coins, Calendar, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';

interface PaymentCalculatorProps {
  onOpenBooking: (projectName?: string) => void;
}

export const PaymentCalculator: React.FC<PaymentCalculatorProps> = ({ onOpenBooking }) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(PROJECTS_DATA[0].id);
  const selectedProject = PROJECTS_DATA.find((p) => p.id === selectedProjectId) || PROJECTS_DATA[0];

  const [totalPricePKR, setTotalPricePKR] = useState<number>(18500000); // 18.5 Million default
  const [downPaymentPercent, setDownPaymentPercent] = useState<number>(15);
  const [durationMonths, setDurationMonths] = useState<number>(36);

  // Calculations
  const downPaymentAmount = (totalPricePKR * downPaymentPercent) / 100;
  const remainingBalance = totalPricePKR - downPaymentAmount;
  // 15% handover, 85% installments remaining
  const handoverAmount = totalPricePKR * 0.10;
  const installmentPool = remainingBalance - handoverAmount;
  const monthlyInstallmentAmount = installmentPool / durationMonths;

  const formatPKR = (num: number) => {
    if (num >= 10000000) {
      return `PKR ${(num / 10000000).toFixed(2)} Crore`;
    }
    if (num >= 100000) {
      return `PKR ${(num / 100000).toFixed(2)} Lakh`;
    }
    return `PKR ${num.toLocaleString()}`;
  };

  return (
    <section id="calculator" className="relative py-24 bg-[#080c15] text-white">
      {/* Background Accent glow */}
      <div className="absolute top-1/2 right-10 w-96 h-96 bg-amber-500/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-panel border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Calculator className="w-3.5 h-3.5 text-amber-400" />
            <span>Smart Estimator</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold tracking-tight">
            Installment & <span className="text-gradient-cyan">Payment Plan Calculator</span>
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
            Customize your budget, down payment percentage, and installment timeline for any UK Developers project in Lahore and Karachi with zero hidden charges.
          </p>
        </div>

        {/* Calculator Widget Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Controls Column */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl glass-panel border border-white/10 space-y-6">
            
            {/* Select Project */}
            <div className="space-y-2">
              <label className="text-xs text-slate-300 font-semibold flex items-center justify-between">
                <span>Select Project:</span>
                <span className="text-cyan-400">{selectedProject.city}</span>
              </label>
              <select
                value={selectedProjectId}
                onChange={(e) => {
                  setSelectedProjectId(e.target.value);
                  const proj = PROJECTS_DATA.find((p) => p.id === e.target.value);
                  if (proj) {
                    // Set default estimated price based on project
                    setTotalPricePKR(18500000);
                  }
                }}
                className="w-full p-3.5 rounded-xl bg-slate-900 border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400"
                id="calc_project_select"
              >
                {PROJECTS_DATA.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} — {p.location} ({p.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Total Property Value Slider */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-semibold">Total Unit Value:</label>
                <span className="text-base font-extrabold text-cyan-300">
                  {formatPKR(totalPricePKR)}
                </span>
              </div>
              <input
                type="range"
                min={7500000}
                max={50000000}
                step={250000}
                value={totalPricePKR}
                onChange={(e) => setTotalPricePKR(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
                id="calc_price_slider"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>PKR 75 Lakhs</span>
                <span>PKR 2.5 Crore</span>
                <span>PKR 5.0 Crore</span>
              </div>
            </div>

            {/* Down Payment % Slider */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-semibold">Down Payment Percentage:</label>
                <span className="text-sm font-bold text-emerald-400">{downPaymentPercent}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={35}
                step={5}
                value={downPaymentPercent}
                onChange={(e) => setDownPaymentPercent(Number(e.target.value))}
                className="w-full accent-emerald-400 cursor-pointer"
                id="calc_downpayment_slider"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>10% (Min)</span>
                <span>15% (Standard)</span>
                <span>25%</span>
                <span>35% (Max)</span>
              </div>
            </div>

            {/* Tenure / Duration Slider */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-semibold">Installment Tenure:</label>
                <span className="text-sm font-bold text-amber-300">{durationMonths} Months ({durationMonths / 12} Years)</span>
              </div>
              <input
                type="range"
                min={12}
                max={48}
                step={6}
                value={durationMonths}
                onChange={(e) => setDurationMonths(Number(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer"
                id="calc_tenure_slider"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>12 Months</span>
                <span>24 Months</span>
                <span>36 Months</span>
                <span>48 Months</span>
              </div>
            </div>

          </div>

          {/* Results Summary Box */}
          <div className="lg:col-span-5 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-[#0b1329] to-[#080c15] border border-cyan-500/30 flex flex-col justify-between space-y-6 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <span className="text-xs font-bold text-cyan-300 uppercase tracking-widest">
                  ESTIMATED PAYMENT SCHEDULE
                </span>
                <span className="px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 text-[10px] font-semibold border border-amber-500/30">
                  0% INTEREST
                </span>
              </div>

              {/* Major Monthly Metric */}
              <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-1">
                <p className="text-[11px] text-cyan-300 uppercase tracking-wider font-semibold">
                  Estimated Monthly Installment
                </p>
                <p className="text-2xl sm:text-3xl font-extrabold text-white">
                  {formatPKR(Math.round(monthlyInstallmentAmount))} <span className="text-xs font-normal text-slate-400">/ mo</span>
                </p>
                <p className="text-[10px] text-slate-400">
                  Over {durationMonths} equal monthly installments
                </p>
              </div>

              {/* Breakdown Grid */}
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5">
                  <span className="text-slate-400">Booking Down Payment ({downPaymentPercent}%):</span>
                  <span className="font-bold text-emerald-400">{formatPKR(Math.round(downPaymentAmount))}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5">
                  <span className="text-slate-400">Remaining Balance:</span>
                  <span className="font-bold text-white">{formatPKR(Math.round(remainingBalance))}</span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-white/5">
                  <span className="text-slate-400">On Physical Handover (10%):</span>
                  <span className="font-bold text-amber-300">{formatPKR(Math.round(handoverAmount))}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Price locked at booking. No inflation surges during construction.</span>
              </div>
            </div>

            <button
              onClick={() => onOpenBooking(selectedProject.title)}
              className="w-full py-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25"
              id="calc_apply_booking_btn"
            >
              <span>Lock This Payment Plan for {selectedProject.title}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
